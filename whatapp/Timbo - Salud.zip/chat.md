# Exportación de chat de WhatsApp: Timbo - Salud
Fecha de exportación: 11 de noviembre de 2026 a las 11:50

---

## 28 de septiembre de 2026

[11:10] __Gonzalez Sectorial creó el grupo__

---

## 2 de octubre de 2026

[7:58] **+54 9 3424 79-1881:** buenos dias. quienes hayan terminado y aprobado el curso, por favor avisar asi pedimos los permisos de Adm Local. mediante ITOP, enviar: Apellido y nombres, CUIL y permisos solicitados.

---

## 13 de octubre de 2026

[8:58] **+54 9 3424 43-4851:** [Imagen] Después no vengan con que están apurados😅

[8:58] **+54 9 3424 43-4851:** Buen día

[8:59] **+54 9 3424 43-4851:** Hace una semana que termine el curso Paso a Paso🤪

[9:03] **+54 9 3424 79-1881:** German. Buenos días.

[9:03] **+54 9 3424 79-1881:** no manejamos los tiempos de la oficina de Capacitación nosotros.

[9:04] **+54 9 3424 79-1881:** ya lo pedimos . cuando tengas los permisos te va a llegar un mail

[9:04] **+54 9 3424 43-4851:** Se ve que ellos tampoco manejan muy bien los tiempos🤣

[18:03] **+54 9 3424 79-1881:** @+54 9 3424 43-4851 revisa.ru casilla de mail a ver si te llegó

---

## 14 de octubre de 2026

[8:23] **+54 9 3424 43-4851:** Buen día

[8:24] **+54 9 3424 43-4851:** Si Andrés ya estoy en curso

[8:24] **+54 9 3424 43-4851:** El Promotor de Innovación nuestro sería Malano?

[8:29] **+54 9 3424 79-1881:** si

---

## 15 de octubre de 2026

[13:02] **+54 9 3424 79-1881:**
> _+54 9 3424 43-4851: El Promotor de Innovación nuestro sería Malano?_
https://www.santafe.gob.ar/ms/innovacion-publica/promotores-innovacion/

[13:12] **+54 9 3424 79-1881:** @+54 9 3491 69-4694 ya tenes los permisos de adm local del Hospital de Ceres

---

## 16 de octubre de 2026

[10:05] **+54 9 3424 79-1881:** Buenos días , los que hayan terminando el curso de adm local, envíen un mail a timbo.salud@ así vamos registrando correctamente,.saludos

[10:37] **+54 9 3424 79-1881:** [Reenviado] Buen día! Alguno mas presenta problemas con Timbo compras? No podemos cargar articulos

[10:37] **+54 9 3424 79-1881:** [Reenviado] Buenos dias Juan nos avisaron que esta caído SIPAF, esto afecta indirectamente al módulo.

[11:01] **+54 9 3424 43-4851:** cheee que buen Sistema este Timbó 🥳🥳

[11:17] **+54 9 3415 86-8926:** _Se eliminó este mensaje_

[11:47] **+54 9 3416 03-6289:** hola buenos dias..si aca en VGG estamos con problemas en Timbó tambien

---

## 19 de octubre de 2026

[8:16] **+54 9 3424 79-1881:** Buenos dias. Spada Milton. ya tiene los permisos otorgados de Adm local para el Hospital JB Iturraspe; Saludos

[8:27] **+54 9 3424 79-1881:** Buenos dias. Irigoyen, Martin ya tiene los permisos otorgados de Adm local para el Hospital de Santo Tome R Nanzar; Saludos

[10:00] **+54 9 3424 79-1881:** Buenos dias. Sanchez, Carina ya tiene los permisos otorgados de Adm local para el Hospital Central de Reconquista; Saludos

[12:55] **+54 9 3424 79-1881:** Buenos dias. Iadanza, Dante y Mallen, Marisa; ya tiene los permisos otorgados de Adm local para el Hospital Provincial del Centenario - Rosario; Saludos

[12:57] **+54 9 3414 02-9204:** Muchas gracias

[12:57] **Gonzalez Sectorial:** [Reenviado] [Documento] Guía en cuatro pasos para solicitar artículos - versión final.pdf

[12:57] **Gonzalez Sectorial:** [Reenviado] [Documento] Guía de Uso - Búsqueda Nomenclador SIPAF y Solicitud de Artículos Faltantes - rev1.pdf

[13:28] **+54 9 3424 79-1881:** Buenos dias. Gorosito Agustina ya tiene los permisos otorgados de Adm local para el Nodo de Salud Santa Fe; Saludos

[13:30] **+54 9 3424 22-7486:** Gracias

---

## 26 de octubre de 2026

[13:09] **+54 9 3424 79-1881:**
> _+54 9 3424 43-4851: Si Andrés ya estoy en curso_
buenas. pudiste terminarlo?

[13:43] **+54 9 3424 43-4851:** naaaaaaaa

[13:43] **+54 9 3424 43-4851:** buen díá

[13:44] **+54 9 3424 43-4851:** mañana veo si junto ganas.. la verdad es que entre que se cayó varias veces y las puteadas de los de Compras

[13:44] **+54 9 3424 43-4851:** no junto ganas.. jajaaja

[13:46] **+54 9 3424 79-1881:** Naa listo,

[13:49] **+54 9 3424 43-4851:** les pedímos desde el Cullen que en vez de que el Sistema de Compras saque en html los archivos, los saque directamente en PDF así son varios pasos menos y se alteran menos😅

[13:49] **+54 9 3424 43-4851:** vamos a ver que responden los de Sistemas

---

## 27 de octubre de 2026

[11:12] **+54 9 3424 79-1881:** buenos dias.

[11:12] **+54 9 3424 79-1881:** Colonnello se le envió email 18-09-26 no esta matriculado en la  plataforma.
Mariano Diaz aún le falta completar el cursado de timbo paso a paso( rindió 3 modulos)
Gomez José Luis aprobó timbo paso a paso. Se lo matricula en administrador local timbo 2026

[11:20] **+54 9 3424 79-1881:** Cabral Fernando aprobó curso timbo paso a paso se lo matricula en administrador local timbo 2026.

[12:44] **+54 9 3462 31-7614:**
> _+54 9 3424 79-1881: Colonnello se le envió email 18-09-26 no esta matriculado en la  plataforma.
Mariano Diaz aún le falta completar el cursado de timbo paso a paso( rindió 3 modulos)
Gomez José Luis aprobó timbo paso a paso. Se lo matricula en administrador local timbo 2026_
Ya no puede matricularse, ya que el periodo finalizó en martes, 23 de junio de 2026, 10:32.

[12:44] **+54 9 3462 31-7614:** como sigo

[13:15] **+54 9 3425 51-1833:** sigo sin poder matricularme al curso de administrador

[13:34] **+54 9 3424 79-1881:**
> _+54 9 3462 31-7614: Ya no puede matricularse, ya que el periodo finalizó en martes, 23 de junio de 2026, 10:32._
tenes que terminar el curso; Timbo. paso a paso. cuando lo apruebes recién ahí te habilitan al curso de Adm local.

[13:34] **+54 9 3424 79-1881:**
> _+54 9 3425 51-1833: sigo sin poder matricularme al curso de administrador_
te va a llegar un mail cuando te matriculen

---

## 29 de octubre de 2026

[8:34] **+54 9 3424 43-4851:** Buen día

[8:34] **+54 9 3424 43-4851:** Andres

[8:34] **+54 9 3424 43-4851:** No tienen para compartir los Videos del Timbo Compras

[8:34] **+54 9 3424 43-4851:** Así no tienen que entrar en YouTube?

[8:35] **+54 9 3424 43-4851:** Acá YouTube está cortado

[8:35] **+54 9 3424 43-4851:** Hay que agregar ACL en los Proxys🤦‍♂️

[8:36] **+54 9 3424 79-1881:**
> _+54 9 3424 43-4851: Hay que agregar ACL en los Proxys🤦‍♂️_
agregaselos.

[8:36] **+54 9 3424 79-1881:** buenos dias.

[8:36] **+54 9 3424 21-7127:** Timboteca

[8:36] **+54 9 3424 21-7127:** [Sticker]

[8:42] **+54 9 3425 48-0456:** Si. Lo de los videos en YouTube es un tema. Aca también esta cortado todo eso. Se crearon Acl solo para YouTube. Pero estaría bueno que accedan desde otro lado también a los videos.

[8:43] **+54 9 3424 79-1881:** https://www.youtube.com/playlist?list=PLJKcMr5XTsSe33vph6nNpxnZpu8D3RsBE

[8:44] **+54 9 3424 79-1881:** y pueden bajarlos en una ubicacion de su red.

[8:44] **+54 9 3424 79-1881:** y compartirlos sino quieren habilitar youtube

[9:37] **+54 9 3415 31-6400:**
> _+54 9 3425 48-0456: Si. Lo de los videos en YouTube es un tema. Aca también esta cortado todo eso. Se crearon Acl solo para YouTube. Pero estaría bueno que accedan desde otro lado también a los videos._
Es que es ilógico. El SCAi bloquea redes sociales y YouTube pero luego suben todas las capacitaciones a esa plataforma. 🤦🏻
Deberían tener su propio servidor sino es contraproducente porque a los usuarios les bloqueas el acceso pero los capacitas por dicho medio

[9:38] **+54 9 3424 79-1881:**
> _+54 9 3415 31-6400: Es que es ilógico. El SCAi bloquea redes sociales y YouTube pero luego suben todas las capacitaciones a esa plataforma. 🤦🏻
Deberían tener su propio servidor sino es contraproducente porque a los usuarios les bloqueas el acceso pero los capacitas por dicho medio_
en SCAI le podes poner el perfil 3 y te habilita.por lo menos por un tiempo

[9:38] **+54 9 3424 79-1881:** hasta que terminen las capacitaciones

[9:39] **+54 9 3415 31-6400:**
> _+54 9 3424 79-1881: en SCAI le podes poner el perfil 3 y te habilita.por lo menos por un tiempo_
Claro pero eso para cada usuario. No sería más lógico que suban a un servidor propio en lugar que tengamos que estar haciendo excepciones

[9:39] **+54 9 3424 79-1881:** [Imagen]

[9:39] **+54 9 3424 79-1881:** como le decia antes a German. aca tambien tenemos bloqueado youtube. para las capacitaciones se los habilitamos un tiempo

[9:40] **+54 9 3424 79-1881:** y sino hay que bajar los videos ponerlos en un recurso compartido

[9:41] **+54 9 3415 31-6400:** Pero porque no crean un servidor y suben ahí el material en lugar de estar teniendo que hacer malabares? Eso es lo que no entiendo.

[9:48] **+54 9 3424 79-1881:**
> _+54 9 3415 31-6400: Pero porque no crean un servidor y suben ahí el material en lugar de estar teniendo que hacer malabares? Eso es lo que no entiendo._
si queres podes hablar con formacion laboral. y plantearlo

[9:50] **+54 9 3415 31-6400:**
> _+54 9 3424 79-1881: si queres podes hablar con formacion laboral. y plantearlo_
No tengo problema. Sería bueno que lo aborde la sectorial ya que no es un problema personal sino por lo que se ve sucede en varios lugares.

---

## 3 de noviembre de 2026

[8:13] **+54 9 3424 79-1881:** Buenos dias. Gomez, Alejandro; ya tiene los permisos otorgados de Adm local para el Hospital Protomédico - Recreo; Saludos

[8:14] **+54 9 3424 79-1881:** Buenos días. Manavella, Martin; ya tiene los permisos otorgados de Adm local para el Hospital A Gutierrez - Venado Tuerto; Saludos

[8:58] **+54 9 3462 55-5050:** hola buenos días gracias buenisimo

---

## 10 de noviembre de 2026

[13:20] __Gonzalez Sectorial añadió a Tú__

---

## 11 de noviembre de 2026

[8:37] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[11:51] **Tú:** Buenos días. Quisiera solicitar acceso para poder matricularme en el curso de Administrador Local. Ya completé y aprobé el curso Paso a Paso.

Comparto mis datos para que puedan gestionar el acceso:

CUIL: 27-37071499-7

IUP: bsolohaga

Correo personal: bereailsolohaga@hotmail.com

Correo institucional de Provincia: bsolohaga@santafe.gov.ar

[11:51] **Damian:** [Mensaje de group-history]

[11:51] **Damian:** [Mensaje de message_history_notice]
