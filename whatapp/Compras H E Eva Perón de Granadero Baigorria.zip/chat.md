# Exportación de chat de WhatsApp: Compras H E Eva Perón de Granadero Baigorria
Fecha de exportación: 11 de noviembre de 2026 a las 11:44

---

## 21 de agosto de 2026

[8:57] __+54 9 3425 38-2374 creó el grupo__

---

## 10 de noviembre de 2026

[8:38] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[8:38] __Paola añadió a Tú__

[8:39] **Paola:** Buen día

[8:39] **Paola:** Agregué a Damian y Berenice de cómputos...que nos ayudarán con este proceso

[8:45] **+54 9 3425 38-2374:** Buen día Pao!! Dale, buenísimo 🙌🏻

[9:39] **+54 9 3413 38-6466:** Cande, bueno ya está firmado el documento oficial. Es el decisorio preventivo, la cuestión es que no tiene numeración

[9:39] **+54 9 3413 38-6466:** Ni fecha

[9:39] **+54 9 3413 38-6466:** Eso debemos ponerlo anteriormente? O como se hace?

[9:39] **+54 9 3425 38-2374:** Por qué preventivo??

[9:40] **+54 9 3415 93-7653:** Hola el decisorio aprobación del consejo

[9:40] **+54 9 3413 38-6466:** Porque es el que se manda previamente al tribunal de cuentas

[9:40] **+54 9 3425 38-2374:** Al expediente y a Timbó compras , tiene que subir el definitivo

[9:40] **+54 9 3415 93-7653:** En este hopital va enumerado y fechado x Secretaría

[9:41] **+54 9 3415 93-7653:** De Dirección

[9:41] **+54 9 3425 38-2374:**
> _+54 9 3413 38-6466: Porque es el que se manda previamente al tribunal de cuentas_
Le corren vista con ese?? Y Lugo otra vez con el decisorios definitivo?

[9:41] **+54 9 3413 38-6466:**
> _+54 9 3425 38-2374: Le corren vista con ese?? Y Lugo otra vez con el decisorios definitivo?_
Sí

[9:41] **+54 9 3415 93-7653:** El decisorio es definitivo

[9:42] **+54 9 3413 38-6466:** Se manda el pliego, con el expediente de Diagnose, pedido, notas y al finalizar el decisorio preventivo con la afectación

[9:43] **+54 9 3413 38-6466:** Cómo hacemos?

[9:47] **+54 9 3413 38-6466:** Aguardo respuesta

[9:50] **+54 9 3425 38-2374:** A Timbó Comoras tienen que vincular el DO que aprueba el pliego ! Eso les va a permitir pasar a la siguiente etapa

[9:51] **+54 9 3413 38-6466:** Sí, eso lo entendí. 
Te consulto por la numeración, lo debemos hacer antes

[9:51] **+54 9 3413 38-6466:** ?

[9:52] **+54 9 3413 38-6466:** Porque ahora si se edita, se rompe la firma. Esa es mi consulta

[10:34] **+54 9 3413 38-6466:** Cande, para archivar o desestimar un documento oficial?

[10:55] **+54 9 3425 38-2374:**
> _+54 9 3413 38-6466: Sí, eso lo entendí. 
Te consulto por la numeración, lo debemos hacer antes_
Exacto! Va completo con todo

[10:56] **+54 9 3425 38-2374:**
> _+54 9 3413 38-6466: Cande, para archivar o desestimar un documento oficial?_
Ya queda creado una vez que está firmado por todos! No lo usen nomas

[10:59] **+54 9 3413 38-6466:**
> _+54 9 3425 38-2374: Ya queda creado una vez que está firmado por todos! No lo usen nomas_
Listo, queda ahí

[10:59] **+54 9 3413 38-6466:**
> _+54 9 3425 38-2374: Exacto! Va completo con todo_
Ahí va

[10:59] **+54 9 3413 38-6466:** Gracias

---

## 11 de noviembre de 2026

[10:46] **+54 9 3413 38-6466:** Buen día

[10:47] **+54 9 3413 38-6466:** [Imagen]

[10:47] **+54 9 3413 38-6466:** Ya completamos la nómina de oferentes y fecha de publicación

[10:48] **+54 9 3413 38-6466:**
> _+54 9 3413 38-6466: Imagen_
Donde busco el link para ponerlo en el portal?

[10:51] **+54 9 3425 38-2374:** buenas!

[10:51] **+54 9 3425 38-2374:** cómo va?

[10:52] **+54 9 3425 38-2374:**
> _+54 9 3413 38-6466: Imagen_
este por lo que veo es su expte.

[10:52] **+54 9 3425 38-2374:**
> _+54 9 3413 38-6466: Ya completamos la nómina de oferentes y fecha de publicación_
buenisimo esto!! van excelente

[10:52] **+54 9 3425 38-2374:** le pudieron correr bien la vista al TCP del decisorio?

[10:52] **+54 9 3425 38-2374:**
> _+54 9 3413 38-6466: Donde busco el link para ponerlo en el portal?_
cual link?

[11:00] **+54 9 3413 38-6466:**
> _+54 9 3425 38-2374: le pudieron correr bien la vista al TCP del decisorio?_
Aún no, estábamos viendo como hacer

[11:01] **+54 9 3413 38-6466:**
> _+54 9 3425 38-2374: cual link?_
Para la publicación en el portal debemos poner el link que lleva a la gestión

[11:01] **+54 9 3425 38-2374:**
> _+54 9 3413 38-6466: Aún no, estábamos viendo como hacer_
Se hace a través de Timbó, por correo electrónico y además se carga en el SIN

[11:04] **+54 9 3425 38-2374:** buen día🤗 cómo va? les comparto el link de acceso a la Circular Nº 04/2026 sobre el Procedimiento para la publicación de las gestiones de contrataciones: https://compras.santafe.gob.ar/wp-content/uploads/sites/87/2026/05/CIRCULAR-004-26.pdf

mediante esta circular, la Subsecretaría de Contrataciones y Gestión de Bienes, aprueba el procedimiento para publicar las gestiones de contrataciones realizadas a través del módulo TIMBÓ COMPRAS.

[11:04] **+54 9 3425 38-2374:** Acá tienen info sobre cómo hacer la publicación en el portal de compras

[11:09] **+54 9 3413 38-6466:**
> _+54 9 3425 38-2374: buen día🤗 cómo va? les comparto el link de acceso a la Circular Nº 04/2026 sobre el Procedimiento para la publicación de las gestiones de contrataciones: https://compras.santafe.gob.ar/wp-content/uploads/sites/87/2026/05/CIRCULAR-004-26.pdf

mediante esta circular, la Subsecretaría de Contrataciones y Gestión de Bienes, aprueba el procedimiento para publicar las gestiones de contrataciones realizadas a través del módulo TIMBÓ COMPRAS._
Sisi esto lo tenemos

[11:15] **+54 9 3413 38-6466:** Para darle vista al Tribunal de cuentas

[11:15] **+54 9 3413 38-6466:** [Imagen]

[11:15] **+54 9 3413 38-6466:** Cómo se completa esto?

[11:16] **+54 9 3413 38-6466:** Porque no me aparece la pestaña que diga "comenzar una carga"

[11:16] **+54 9 3413 38-6466:** [Imagen]

[11:16] **+54 9 3413 38-6466:**
> _+54 9 3413 38-6466: Imagen_
El link ese te manda acá

[11:17] **+54 9 3425 38-2374:** [Reenviado] [Documento] Carga y Edicion SIN.pdf

[11:17] **+54 9 3425 38-2374:** [Reenviado] https://app.santafe.gov.ar/normativa

[11:18] **+54 9 3413 38-6466:**
> _+54 9 3425 38-2374: Documento: Carga y Edicion SIN.pdf_
Ah, no es lo mismo que está en el instructivo

[11:18] **+54 9 3413 38-6466:** Gracias

[11:22] **+54 9 3413 38-6466:** [Imagen]

[11:22] **+54 9 3413 38-6466:** No nos abre el link

[11:24] **+54 9 3425 38-2374:** [Imagen] esos son los usuarios que pueden acceder a cargar en el SIN

[11:25] **+54 9 3425 38-2374:** tienen que ingresar desde la compu y tener conexión a la red

[11:28] **+54 9 3413 38-6466:** Ahhh

[11:28] **+54 9 3413 38-6466:** Bueno, no podemos estar habilitadas? Nuestros compañeros ya tienen sus tareas, siempre nos ocupamos nosotras de eso

[11:29] **+54 9 3425 38-2374:** sii, no hay drama! les damos el acceso! les paso la info que necesito para hacerlo

[11:30] **+54 9 3425 38-2374:** Para gestionar la creación de unsuarios en el Sistema SIN, será necesario completar el archivo Excel proporcionado con la información correspondiente a:

* Usuarios responsables de la carga de actos administrativos en el Sistema SIN.

Una vez recibida la información solicitada, se generará un ticket en iTop dirigido a la Secretaría de Tecnologías para la Gestión (STG), a fin de gestionar la creación de los usuarios correspondientes en el Sistema SIN.

Importante: en caso de que alguno de los usuarios no cuente con un correo electrónico oficial, deberá indicarse en el archivo para gestionar su creación.

La información deberá remitirse a cualquiera de las siguientes direcciones de correo electrónico: jmalano@santafe.gov.ar o ctognotti@santafe.gov.ar.

[11:30] **+54 9 3425 38-2374:** [Documento] Planilla de datos BDN.xlsx

[11:30] **+54 9 3413 38-6466:** Dale Cande

[11:30] **+54 9 3425 38-2374:** de igual manera, este decisorio que ya tienen prueben de cargarlo con los usuarios que ya estan habilitados

[11:31] **+54 9 3425 38-2374:** ´porque la creacion de usuarios para carga en el SIN suele demorar unos días y se les puede pasar el plazo para correr la vista al TCP del decisorio

[11:43] **+54 9 3413 38-6466:** Sí lo está cargando Andrés

[11:45] **+54 9 3425 38-2374:** buenísimo🙌🏻
